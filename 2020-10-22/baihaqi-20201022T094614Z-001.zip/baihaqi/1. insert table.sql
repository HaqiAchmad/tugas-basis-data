INSERT INTO karyawan (nama, id_dep) 
VALUES 
('Agus', 10),
('Budi', 16),
('Citra', 12),
('Dani', 17);

INSERT INTO departemen (id_dep, nama_dep) 
VALUES 
(10, 'Penelitian'),
(11, 'Pemasaran'),
(12, 'SDM'),
(13, 'Keuangan');