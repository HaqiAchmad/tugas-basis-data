# Union 
SELECT nama, id_dep 
FROM karyawan 
UNION 
SELECT nama, id_dep 
FROM karyawan2;