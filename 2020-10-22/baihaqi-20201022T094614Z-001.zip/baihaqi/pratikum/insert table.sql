INSERT INTO mahasiswa 
VALUES 
(101, "Arif", "L", "Jl. Kenangan"),
(102, "Budi", "L", "Jl. Jombang"),
(103, "Wati", "P", "Jl. Surabaya"),
(104, "Ika", "P", "Jl. Jombang"),
(105, "Tono", "L", "Jl. Jakarta"),
(106, "Iwan", "L", "Jl. Bandung"),
(107, "Sari", "P", "Jl. Malang");

INSERT INTO ambil_mk 
VALUES 
(101, "PTI447"),
(103, "TIK333"),
(104, "PTI333"),
(111, "PTI123"),
(123, "PTI9999");

INSERT INTO matakuliah 
VALUES 
("PTI447", "Pratikum Basis Data", 1, 3),
("TIK342", "Pratikum Basis Data", 1, 3),
("PTI333", "Basis Data Terdistribusi", 3, 5),
("TIK123", "Jaringan Komputer", 2, 5),
("TIK333", "Sistem Operasi", 3, 5),
("PTI123", "Grafika Mutltimedia", 3, 5),
("PTI777", "Sistem Informasi", 2, 3);