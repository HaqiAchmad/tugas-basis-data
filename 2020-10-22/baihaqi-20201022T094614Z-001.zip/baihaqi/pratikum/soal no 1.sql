SELECT * FROM mahasiswa 
INNER JOIN ambil_mk 
ON mahasiswa.nim = ambil_mk.nim;